/*
�	��renci:
----o	��renci ID (primary key)
----o	Ad Soyad
----o	��renci Numaras�
o	Telefon Numaras� --> gerek yok
----o	E-posta
o	S�n�f
o	B�l�m

--------�	Ders:
--------o	Ders ID (primary key)
--------o	Ders Ad�
--------o	��retmen ID (foreign key)

�	��retmen:
----o	��retmen ID (primary key)
----o	Ad Soyad
o	Bran�
----o	Telefon Numaras� --> gerek yok
----o	E-posta

--------�	Not:
--------o	Not ID (primary key)
--------o	��renci ID (foreign key)
--------o	Ders ID (foreign key)
--------o	Vize Notu
--------o	Final Notu

--------�	Devams�zl�k:
--------o	Devams�zl�k ID (primary key)
--------o	��renci ID (foreign key)
--------o	Ders ID (foreign key)
--------o	Devams�zl�k Say�s�

--------�	Veli:
--------o	Veli ID (primary key)
--------o	Ad Soyad
--------o	Telefon Numaras� --> gerek yok
--------o	E-posta
--------o	�ocuk ID (foreign key)

*/