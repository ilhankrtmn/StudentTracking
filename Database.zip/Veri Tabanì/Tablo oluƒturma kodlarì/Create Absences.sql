Create table Absences
(
Id int IDENTITY(1,1) PRIMARY KEY,
StudentId int not null,
LessonId int not null,
Count int not null default 0
)