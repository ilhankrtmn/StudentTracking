/*
Create Table Users 
(
Id int IDENTITY(1,1) PRIMARY KEY,
UserTypeId int not null,
Name varchar(50) not null,
Surname varchar(50) not null,
StudentNumber int null,
Email varchar(80) not null,
Password varchar(100) not null,
ChildrenId int null,
Status bit not null default 0,
CreatedDate Datetime  not null default getdate(),
UpdatedDate Datetime null
)


Insert Into Users values (1,'admin','admin',null,'admin@admin.com',123,null,1,GETDATE(),null)
*/