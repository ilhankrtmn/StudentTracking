Create Table Lessons 
(
Id int IDENTITY(1,1) PRIMARY KEY,
TeacherId int not null,
Name varchar(150) not null,
ImgUrl varchar(1000) not null,
Status bit default 0,
CreatedDate Datetime default GETDATE()
)