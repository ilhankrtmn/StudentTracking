CREATE TABLE [dbo].[UserTypes]
(
	[Id] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Name] [varchar](20) NOT NULL
)