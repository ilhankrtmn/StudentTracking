/*
CREATE TABLE [dbo].[OutgoingMails](
	[Id] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[SendUserId] [int] NULL DEFAULT 0,
	[RecipientUserId] [int] NOT NULL DEFAULT 0,
	[Email] [varchar](100) NOT NULL,
	[Subject] [varchar](250) NOT NULL,
	[Message] [varchar](1000) NOT NULL,
	[Status] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL DEFAULT GETDATE()
)
*/