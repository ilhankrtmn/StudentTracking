Create Table Grades
(
Id int IDENTITY(1,1) PRIMARY KEY,
StudentId int not null,
LessonId int not null,
MidtermGrade int not null default 0,
FinalGrade int not null default 0
)