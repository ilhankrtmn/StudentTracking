select * from Users 

select * from Absences 
select * from Grades 
select * from Lessons 

select * from OutgoingMails 
select * from UserEmailOtps 
select * from Users 
select * from UserTypes